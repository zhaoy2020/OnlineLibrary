A simple tool for Deep Learning with PyTorch.
